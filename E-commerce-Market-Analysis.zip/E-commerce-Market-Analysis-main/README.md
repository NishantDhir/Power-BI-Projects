# E-commerce-Market-Analysis
<p align="center"
   <img src="(https://github.com/NishantDhir/E-commerce-Market-Analysis/blob/main/Ecommerce_page-0001.jpg)" />
</p>

# E-commerce
A data analysis project with the help of SQL, Excel and PowerBI.

### What's included?
```bash
   # Datasets
   Order Analysis, Shipment Analysis & Purchases.

Job Role: Data Analyst
Domain: E-commerce
Function: Marketing

   # Data Visualization report(s).
```

### What's required?
1. Loading Data Set for ETL in Power BI and implementing DAX measures.
2. Data cleaning with the help of query editor tool.
3. Performing Data modeling operations.
4. Use of star schema and/ or snow-flake schema.
4. Creating relationship between the tables containing same variables by indetifying Primary & Foreign Key.
5. Data visualization with the help of PowerBI.
6. E-commerce are losing its market share and revenue in the e-commerce category. As a Data Analyst, you have been provided with sample data to find out key metrics like Sales, Profit, Quantity, and Discount.
### Findings
- In Order Analysis, the total sales for Product Performance accounted for $2.3M, generating a profit of $286k for a total quantity sold of 38k units.
- In Order Analysis, the total purchase for Customer Performance accounted for $230, on a price of $29 for a total quantity sold of 10k units.
- In Order Analysis, the total purchase for Customer Performance accounted for $230, on a price of $29 for a total quantity sold of 10k units.
- Year on Year measures for Sales is 31%. The occupancy differs with a rate of almost 1% with Profit and Quantity.
- In Shipment Analysis, the total sales for Product Performance accounted for $9100, on a profit of $2k for a total quantity sold of 14k units.
- In Shipment Analysis, the total purchase for Custmor Performance accounted for $214, on a price of $3k for a total quantity sold of 600k units.
