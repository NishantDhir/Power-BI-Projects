# Financial-and-Sales-Report
<p align="center"
   <img src="(https://github.com/NishantDhir/Financial-and-Sales-Report/blob/main/Reports-1_page-0001.jpg)" />
</p>

# E-commerce
A data analysis project with the help of Excel and PowerBI.

### What's included?
```bash
   # Datasets
   Sale Price, Unit Sold & Manufacturing Price.

Job Role: Data Analyst
Domain: E-commerce
Function: Sales and Finance

   # Data Visualization report(s).
```

### What's required?
1. Loading Data Set for ETL in Power BI.
2. Data cleaning with the help of query editor tool.
3. Performing Data modeling operations.
4. Use of star schema and/ or snow-flake schema.
4. Creating relationship between the tables containing same variables by indetifying Primary & Foreign Key.
5. Data visualization with the help of PowerBI.
6. Excel store are planning to have an overview on their sales and finance in the e-commerce category. As a Data Analyst, you have been provided with sample data to find out key metrics like Sales, Gross Sales, Quantity Sold, and Discount.

### Findings
- In Financial Analysis, United States of America bought the highest number of units which generated a revenue across $2995,541 through Goverment Segment.
- In Financial Analysis, Carretera was the highest selling product which generated a gross sale of $14,937,520.5.
- In Financial Analysis, Q2-Q3 saw an increase in COGS and in Q3 the sales also increased which could be considered as a positive outlook.
- In Sales Analysis, Canada bought the highest number of units which generated a revenue across $247,428.50 through Small Businesses.
- In Sales Analysis, Paseo was the highest selling product which generated a gross sale of $1,207,500.
- In Sales Analysis, Q1-Q4 saw a straight line in terms of manufacturing price which is good sign for cost control and provides an edge over the competitors. 
