<p align="center"
   <img src="https://github.com/NishantDhir/AdventureWorks-Dataset-Dashboard_BusinessAnalysis/blob/main/Report.png" />
</p>

# AdventureWorks Cycles
A business analysis project with the help of dataset and PowerBI.

### What's included?
```bash
   # Datasets
   Calendar, Customers, Product Categories, Subcategories, Products, Returns &  Territories.

   # Data Visualization report(s).
```

### What's required?
1. Data cleaning with the help of query editor tool (data modelling).
2. Creating new columns and calculating new measures by DAX functions.
3. Use of star schema and snow-flake schema.
4. Creating relationship between the tables containing same variables.
5. Data visualization with the help of PowerBI.
6. Categorized the report on the basis of company's overview, product details, customer details, artificial intelligence & decomposition tree.

### Findings
- The product category 'accessories' had the highest number of orders out of all.
- The all time top product (by orders) was All-purpose bike stand.
- The goal of achieving $1.77M was exceeded by 3.31%, clocking to $1.83M.
- The highest number of orders belonged to females. 
- Out of the total, 30% of the buyers belonged to Professionals who had average income.
- The key influencer was the price of USD. Whenever the price went up, the number of backers also went up significantly.
- The most popular sub-category was 'Games' with Tabletop Games being the highest.
