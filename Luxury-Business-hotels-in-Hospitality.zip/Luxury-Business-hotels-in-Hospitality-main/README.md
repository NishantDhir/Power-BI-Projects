# Luxury-Business-hotels-in-Hospitality
<p align="center"
   <img src="(https://github.com/NishantDhir/Luxury-Business-hotels-in-Hospitality/blob/main/Atliq%20Hospitality.jpg)" />
</p>

# AtliQ Hotels
A data analysis project with the help of Excel and PowerBI.

### What's included?
```bash
   # Datasets
   ADR, Occupancy% & RevPAR.

Job Role: Data Analyst
Domain: Hospitality
Function: Revenue Management

   # Data Visualization report(s).
```

### What's required?
1. Loading Data Set for ETL in Power BI and implementing DAX measures.
2. Data cleaning with the help of query editor tool.
3. Performing Data modeling operations.
4. Use of star schema and/ or snow-flake schema.
4. Creating relationship between the tables containing same variables by indetifying Primary & Foreign Key.
5. Data visualization with the help of PowerBI.
6. AtliQ Grands are losing its market share and revenue in the luxury/business hotels category. As a Data Analyst, you have been provided with sample data to find out key metrics like RevPar, DSRN, DBRN, and DURN.
### Findings
- Business Category generated 61% of revenue.
- Atliq Exotica which was located in Mumbai generated a revenue of 9M with an average rating of 4.29 for their Presidential Suite.
- Key metrics such as RevPAR, ADR, and Occupancy% saw a constant increase.
- Week on Week measures for a Premium room in Delhi has a big amount of difference. The occupancy differs by 6% with an ADR of almost ₹1000. There is a 1% increase in realization during weekdays.
- Elite room in Bangalore is majorly booked from the hotel website which means 72.27% of the customers prefer direct online booking.
- Standard room in Hyderabad is majorly booked offline which means 73.10% of the customer acquisition comes directly which makes a good presence in the industry due to factors like location & service.
