# Altiq-Supply-Chain-Analysis
<p align="center"
   <img src="https://github.com/NishantDhir/Altiq--Supply-Chain-Analysis/blob/main/supply%20chain.pdf" />
</p>

# AtliQo Mart
A data analysis project with the help of dataset , SQL and PowerBI.

### What's included?
```bash
   # Datasets
   Cities, Product Name, Customer Name, OTIF% &  Metrics.

Job Role: Data Analyst
Domain: FMCG
Function: Supply Chain Operations

   # Data Visualization report(s).
```

### What's required?
1. Running Analysis in MYSQL Workbench.
2. Data cleaning with the help of query editor tool (data modelling).
3. Creating new columns and calculating new measures by DAX functions.
4. Use of star schema and/ or snow-flake schema.
4. Creating relationship between the tables containing same variables.
5. Data visualization with the help of PowerBI.
6. The management wants to fix this issue before expanding to other cities and requested their supply chain analytics team to track the ’On time’ and ‘In Full’ delivery service level for all the customers daily basis so that they can respond swiftly to these issues..

### Findings
- The Market share of AtliQo was the highest specifiying its importance in tbe market.
- The monthly target trendlines records a downfall with their products with lower order quanity but with a upscale in On time delivery. This means that with less orders we are able to deliver things on time. In case, more orders come in that case we need to hire more people for delivery.
- The Reliance and Vijay Stores are the best performers where there is an increase in monthly orders.
- A parrallel trend can be observed with on time delivery and order quanity. If the order quanity is more then the delivery time is more and vice a versa.
